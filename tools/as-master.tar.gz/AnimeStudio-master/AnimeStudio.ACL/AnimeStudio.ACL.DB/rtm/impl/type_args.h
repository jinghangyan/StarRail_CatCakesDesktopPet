#pragma once

////////////////////////////////////////////////////////////////////////////////
// The MIT License (MIT)
//
// Copyright (c) 2018 Nicholas Frechette & Realtime Math contributors
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
////////////////////////////////////////////////////////////////////////////////

#include "rtm/types.h"
#include "rtm/version.h"

//////////////////////////////////////////////////////////////////////////
// Register passing typedefs
//////////////////////////////////////////////////////////////////////////

#if defined(RTM_USE_VECTORCALL)
	#include "rtm/impl/type_args.vectorcall.impl.h"
#elif defined(RTM_NEON64_INTRINSICS)
	#include "rtm/impl/type_args.neon64.impl.h"
#elif defined(RTM_NEON_INTRINSICS)
	#include "rtm/impl/type_args.neon.impl.h"
#elif defined(RTM_ARCH_X64) && defined(RTM_COMPILER_GCC)
	#include "rtm/impl/type_args.x64_gcc.impl.h"
#elif defined(RTM_ARCH_X64) && defined(RTM_COMPILER_CLANG)
	#include "rtm/impl/type_args.x64_clang.impl.h"
#else
	#include "rtm/impl/type_args.other.impl.h"
#endif
