#pragma once

////////////////////////////////////////////////////////////////////////////////
// The MIT License (MIT)
//
// Copyright (c) 2018 Nicholas Frechette & Animation Compression Library contributors
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
////////////////////////////////////////////////////////////////////////////////

namespace acl
{
	//////////////////////////////////////////////////////////////////////////
	// This class is meant to encapsulate a simple error message and easily
	// coerce with 'bool' in order to simplify and clean up error handling.
	// In an ideal world, I would love for a C++11 equivalent of std::result in Rust.
	//////////////////////////////////////////////////////////////////////////
	class ErrorResult
	{
	public:
		ErrorResult() : m_error(nullptr) {}
		explicit ErrorResult(const char* error) : m_error(error) {}

		bool empty() const { return m_error == nullptr; }
		bool any() const { return m_error != nullptr; }

		const char* c_str() const { return m_error != nullptr ? m_error : ""; }

		void reset() { m_error = nullptr; }

	private:
		const char*		m_error;
	};
}
